


const Home=()=>{
    return(
        <>
         <h1 align="center"> Welcome To Home Page</h1>
        </>
    )
}

export default Home;


const Error=()=>{
    return(
        <>
          <h1 align="center"> Error</h1>
        </>
    )
}

export default Error;